package com.example.relationshipJPA.Entity;

import lombok.Data;

@Data
public class RefreshTokenRequest {

    private String refreshToken;
}
