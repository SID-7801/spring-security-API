package com.example.relationshipJPA.Entity;



public enum Role {
    USER,
    ADMIN
}

