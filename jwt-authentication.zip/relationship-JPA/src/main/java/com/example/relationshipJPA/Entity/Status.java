package com.example.relationshipJPA.Entity;

public enum Status {

    PENDING,
    PROGRESS,
    COMPLETED
}
