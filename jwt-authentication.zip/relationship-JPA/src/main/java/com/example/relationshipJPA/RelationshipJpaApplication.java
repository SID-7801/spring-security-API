package com.example.relationshipJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationshipJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelationshipJpaApplication.class, args);
	}

}
