package com.example.relationshipJPA.Repository;

import com.example.relationshipJPA.Entity.Complain;
import com.example.relationshipJPA.Entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ComplainRepository extends JpaRepository<Complain, Long> {

//    Optional<Member> findById(long id);
}
