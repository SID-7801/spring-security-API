package com.example.relationshipJPA.Service;

import com.example.relationshipJPA.Entity.Complain;

public interface ComplainService {

    Complain saveComplain(Complain complain);
}
