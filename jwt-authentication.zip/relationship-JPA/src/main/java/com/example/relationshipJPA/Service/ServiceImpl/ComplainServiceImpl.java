package com.example.relationshipJPA.Service.ServiceImpl;

import com.example.relationshipJPA.Entity.Complain;
import com.example.relationshipJPA.Repository.ComplainRepository;
import com.example.relationshipJPA.Service.ComplainService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ComplainServiceImpl implements ComplainService {

    private ComplainRepository complainRepository;
    @Override
    public Complain saveComplain(Complain complain) {
        return complainRepository.save(complain);
    }
}
