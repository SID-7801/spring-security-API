package com.example.relationshipJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationshipJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
